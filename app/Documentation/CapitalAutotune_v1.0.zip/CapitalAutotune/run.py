#!/usr/bin/env python3
"""
Capital Autotune Workshop System
Launcher — run this file to start the application
"""
import os, sys

# Ensure we're in the right directory
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SRC_DIR = os.path.join(BASE_DIR, 'src')
DATA_DIR = os.path.join(BASE_DIR, 'data')

sys.path.insert(0, SRC_DIR)
os.chdir(BASE_DIR)

# Check dependencies
missing = []
for pkg in ['tkinter', 'reportlab', 'openpyxl', 'pandas']:
    try:
        if pkg == 'tkinter':
            import tkinter
        elif pkg == 'reportlab':
            import reportlab
        elif pkg == 'openpyxl':
            import openpyxl
        elif pkg == 'pandas':
            import pandas
    except ImportError:
        missing.append(pkg)

if missing:
    print(f"ERROR: Missing packages: {', '.join(missing)}")
    print("Please run: pip install reportlab openpyxl pandas")
    input("Press Enter to exit...")
    sys.exit(1)

from app import main
main()
