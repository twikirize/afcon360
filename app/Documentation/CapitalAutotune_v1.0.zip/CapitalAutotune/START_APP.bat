@echo off
title Capital Autotune Workshop System
echo Starting Capital Autotune Workshop System...
cd /d "%~dp0"
python run.py
if errorlevel 1 (
    echo.
    echo ERROR: Could not start the application.
    echo Make sure Python is installed and run: pip install reportlab openpyxl pandas
    pause
)
