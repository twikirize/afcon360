import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog
import json, os, sys, shutil
from datetime import datetime, timedelta
import threading

# Add src to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import database as db
from pdf_generator import build_quote_pdf, build_quote_excel

# ─────────────────────────────────────────────
# THEME
# ─────────────────────────────────────────────
THEME = {
    'bg': '#f0f4f8',
    'sidebar': '#1a3a5c',
    'sidebar_hover': '#2a5080',
    'sidebar_active': '#f0a500',
    'accent': '#1a3a5c',
    'accent2': '#f0a500',
    'white': '#ffffff',
    'light': '#e8f0fe',
    'text': '#1a1a2e',
    'text_light': '#555577',
    'danger': '#c0392b',
    'success': '#27ae60',
    'border': '#d0d8e8',
    'row_alt': '#f7f9fc',
    'header_bg': '#1a3a5c',
    'header_fg': '#ffffff',
}

FONT = ('Helvetica', 10)
FONT_BOLD = ('Helvetica', 10, 'bold')
FONT_SM = ('Helvetica', 9)
FONT_LG = ('Helvetica', 13, 'bold')
FONT_XL = ('Helvetica', 16, 'bold')

# ─────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────
def fmt_ugx(val):
    try:
        return f"{float(val):,.0f}"
    except:
        return "0"

def save_to_folder(file_path, quote_data):
    """Auto-save to organised folder structure"""
    base = db.get_setting('output_folder', os.path.expanduser('~/Desktop/CapitalAutotune_Quotes'))
    customer = (quote_data.get('customer_name') or 'Unknown_Customer').replace('/', '_').replace('\\', '_')
    reg = (quote_data.get('reg_no') or 'Unknown_Reg').replace('/', '_').replace(' ', '_')
    folder = os.path.join(base, customer, reg)
    os.makedirs(folder, exist_ok=True)
    dest = os.path.join(folder, os.path.basename(file_path))
    shutil.copy2(file_path, dest)
    return dest

# ─────────────────────────────────────────────
# REUSABLE WIDGETS
# ─────────────────────────────────────────────
class ScrollFrame(tk.Frame):
    def __init__(self, parent, **kw):
        outer = tk.Frame(parent, bg=kw.get('bg', THEME['bg']))
        outer.pack(fill='both', expand=True)
        canvas = tk.Canvas(outer, bg=kw.get('bg', THEME['bg']), highlightthickness=0)
        scrollbar = ttk.Scrollbar(outer, orient='vertical', command=canvas.yview)
        super().__init__(canvas, bg=kw.get('bg', THEME['bg']))
        self.bind('<Configure>', lambda e: canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.create_window((0, 0), window=self, anchor='nw')
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side='left', fill='both', expand=True)
        scrollbar.pack(side='right', fill='y')
        canvas.bind_all('<MouseWheel>', lambda e: canvas.yview_scroll(-1*(e.delta//120), 'units'))

class LabelEntry(tk.Frame):
    def __init__(self, parent, label, width=22, **kw):
        super().__init__(parent, bg=THEME['bg'])
        tk.Label(self, text=label, bg=THEME['bg'], fg=THEME['text'], font=FONT_SM,
                 anchor='w', width=18).pack(side='left')
        self.var = tk.StringVar(value=kw.get('default', ''))
        self.entry = tk.Entry(self, textvariable=self.var, font=FONT, width=width,
                              relief='solid', bd=1, bg=THEME['white'])
        self.entry.pack(side='left', padx=(0, 10))
    def get(self): return self.var.get()
    def set(self, v): self.var.set(v)

class SectionTitle(tk.Label):
    def __init__(self, parent, text, **kw):
        super().__init__(parent, text=text, font=FONT_BOLD, bg=THEME['header_bg'],
                         fg=THEME['header_fg'], padx=10, pady=4, anchor='w')

class ActionBtn(tk.Button):
    def __init__(self, parent, text, cmd, color=None, **kw):
        bg = color or THEME['accent']
        super().__init__(parent, text=text, command=cmd, font=FONT_BOLD,
                         bg=bg, fg='white', relief='flat', padx=12, pady=5,
                         cursor='hand2', activebackground=THEME['accent2'],
                         activeforeground='white', **kw)

# ─────────────────────────────────────────────
# QUOTE BUILDER
# ─────────────────────────────────────────────
class QuoteBuilder(tk.Frame):
    def __init__(self, parent, app, edit_data=None):
        super().__init__(parent, bg=THEME['bg'])
        self.app = app
        self.items = []
        self.edit_data = edit_data
        self._build_ui()
        if edit_data:
            self._load_edit(edit_data)

    def _build_ui(self):
        # ── Top bar
        topbar = tk.Frame(self, bg=THEME['accent'], pady=6)
        topbar.pack(fill='x')
        tk.Label(topbar, text='📋  New Quotation', font=FONT_XL,
                 bg=THEME['accent'], fg='white').pack(side='left', padx=15)
        ActionBtn(topbar, '💾 Save Quote', self._save_quote, color=THEME['success']).pack(side='right', padx=5)
        ActionBtn(topbar, '📄 PDF', self._export_pdf).pack(side='right', padx=2)
        ActionBtn(topbar, '📊 Excel', self._export_excel, color='#217346').pack(side='right', padx=2)
        ActionBtn(topbar, '🧾 → Invoice', self._to_invoice, color=THEME['accent2']).pack(side='right', padx=2)
        ActionBtn(topbar, '🗑 Clear', self._clear, color=THEME['danger']).pack(side='right', padx=10)

        # ── Main body split
        body = tk.Frame(self, bg=THEME['bg'])
        body.pack(fill='both', expand=True, padx=10, pady=8)

        left = tk.Frame(body, bg=THEME['bg'])
        left.pack(side='left', fill='both', expand=False, padx=(0, 8))
        right = tk.Frame(body, bg=THEME['bg'])
        right.pack(side='left', fill='both', expand=True)

        # ── LEFT: Customer & Vehicle
        SectionTitle(left, '👤  Customer & Vehicle Details').pack(fill='x', pady=(0, 4))
        detail_frame = tk.Frame(left, bg=THEME['bg'])
        detail_frame.pack(fill='x')

        self.f_customer   = LabelEntry(detail_frame, 'Customer Name:',   width=28); self.f_customer.pack(pady=2)
        self.f_cust_id    = LabelEntry(detail_frame, 'Customer ID:',      width=28); self.f_cust_id.pack(pady=2)
        self.f_reg        = LabelEntry(detail_frame, 'Reg No:',           width=28); self.f_reg.pack(pady=2)
        self.f_mileage    = LabelEntry(detail_frame, 'Mileage:',          width=28); self.f_mileage.pack(pady=2)
        self.f_salesperson= LabelEntry(detail_frame, 'Salesperson:',      width=28); self.f_salesperson.pack(pady=2)
        self.f_job        = LabelEntry(detail_frame, 'Job Description:',  width=28, default='M/V Repair and maintenance'); self.f_job.pack(pady=2)
        self.f_notes      = LabelEntry(detail_frame, 'Notes:',            width=28); self.f_notes.pack(pady=2)

        # Vehicle + pricelist selectors
        tk.Label(left, text='Vehicle:', font=FONT_SM, bg=THEME['bg'], anchor='w').pack(fill='x', pady=(6, 0))
        self.vehicle_var = tk.StringVar()
        self.vehicle_cb = ttk.Combobox(left, textvariable=self.vehicle_var, font=FONT, width=34, state='readonly')
        self.vehicle_cb.pack(fill='x', pady=2)
        self.vehicle_cb.bind('<<ComboboxSelected>>', self._on_vehicle_change)

        tk.Label(left, text='Price List:', font=FONT_SM, bg=THEME['bg'], anchor='w').pack(fill='x', pady=(4, 0))
        self.pricelist_var = tk.StringVar()
        self.pricelist_cb = ttk.Combobox(left, textvariable=self.pricelist_var, font=FONT, width=34, state='readonly')
        self.pricelist_cb.pack(fill='x', pady=2)
        self.pricelist_cb.bind('<<ComboboxSelected>>', self._on_vehicle_change)

        self._refresh_vehicles()

        # ── LEFT: Part Search
        tk.Frame(left, height=10, bg=THEME['bg']).pack()
        SectionTitle(left, '🔍  Search & Add Parts').pack(fill='x', pady=(0, 4))

        srch_frame = tk.Frame(left, bg=THEME['bg'])
        srch_frame.pack(fill='x')
        self.search_var = tk.StringVar()
        self.search_var.trace('w', self._on_search)
        tk.Label(srch_frame, text='Type part name:', font=FONT_SM, bg=THEME['bg']).pack(anchor='w')
        self.search_entry = tk.Entry(srch_frame, textvariable=self.search_var, font=FONT,
                                     relief='solid', bd=1, bg=THEME['white'])
        self.search_entry.pack(fill='x', pady=2)

        # Results listbox
        list_frame = tk.Frame(left, bg=THEME['bg'])
        list_frame.pack(fill='x')
        self.results_list = tk.Listbox(list_frame, height=8, font=FONT_SM,
                                        selectmode='single', activestyle='dotbox',
                                        bg=THEME['white'], relief='solid', bd=1)
        self.results_list.pack(side='left', fill='x', expand=True)
        sb = ttk.Scrollbar(list_frame, command=self.results_list.yview)
        sb.pack(side='right', fill='y')
        self.results_list.config(yscrollcommand=sb.set)
        self.results_list.bind('<Double-Button-1>', self._add_from_list)
        self.results_list.bind('<Return>', self._add_from_list)

        # Qty + custom price + add button
        add_row = tk.Frame(left, bg=THEME['bg'])
        add_row.pack(fill='x', pady=4)
        tk.Label(add_row, text='Qty:', font=FONT_SM, bg=THEME['bg']).pack(side='left')
        self.qty_var = tk.StringVar(value='1')
        tk.Entry(add_row, textvariable=self.qty_var, font=FONT, width=5,
                 relief='solid', bd=1, bg=THEME['white']).pack(side='left', padx=4)
        tk.Label(add_row, text='Unit Price (leave blank=auto):', font=FONT_SM, bg=THEME['bg']).pack(side='left')
        self.custom_price_var = tk.StringVar()
        tk.Entry(add_row, textvariable=self.custom_price_var, font=FONT, width=12,
                 relief='solid', bd=1, bg=THEME['white']).pack(side='left', padx=4)
        ActionBtn(add_row, '+ Add', self._add_selected, color=THEME['success']).pack(side='left', padx=4)

        # Manual custom part
        tk.Frame(left, height=6, bg=THEME['bg']).pack()
        SectionTitle(left, '✏️  Add Custom Part').pack(fill='x', pady=(0, 4))
        custom_frame = tk.Frame(left, bg=THEME['bg'])
        custom_frame.pack(fill='x')
        tk.Label(custom_frame, text='Part name:', font=FONT_SM, bg=THEME['bg']).pack(anchor='w')
        self.custom_name_var = tk.StringVar()
        tk.Entry(custom_frame, textvariable=self.custom_name_var, font=FONT,
                 relief='solid', bd=1, bg=THEME['white']).pack(fill='x', pady=2)
        cust_row2 = tk.Frame(custom_frame, bg=THEME['bg'])
        cust_row2.pack(fill='x')
        tk.Label(cust_row2, text='Price:', font=FONT_SM, bg=THEME['bg']).pack(side='left')
        self.custom_manual_price = tk.StringVar()
        tk.Entry(cust_row2, textvariable=self.custom_manual_price, font=FONT, width=14,
                 relief='solid', bd=1, bg=THEME['white']).pack(side='left', padx=4)
        tk.Label(cust_row2, text='Qty:', font=FONT_SM, bg=THEME['bg']).pack(side='left')
        self.custom_manual_qty = tk.StringVar(value='1')
        tk.Entry(cust_row2, textvariable=self.custom_manual_qty, font=FONT, width=5,
                 relief='solid', bd=1, bg=THEME['white']).pack(side='left', padx=4)
        ActionBtn(cust_row2, '+ Add Custom', self._add_custom_item, color='#7b4fc8').pack(side='left', padx=4)

        # Labour
        labour_frame = tk.Frame(left, bg=THEME['bg'])
        labour_frame.pack(fill='x', pady=4)
        tk.Label(labour_frame, text='Labour (UGX):', font=FONT_SM, bg=THEME['bg']).pack(side='left')
        self.labour_var = tk.StringVar(value='0')
        self.labour_var.trace('w', lambda *a: self._recalc())
        tk.Entry(labour_frame, textvariable=self.labour_var, font=FONT, width=16,
                 relief='solid', bd=1, bg=THEME['white']).pack(side='left', padx=4)

        # VAT toggle
        self.show_vat = tk.BooleanVar(value=db.get_setting('show_vat_on_quote', '1') == '1')
        tk.Checkbutton(left, text='Include VAT (18%)', variable=self.show_vat,
                       bg=THEME['bg'], font=FONT_SM, command=self._recalc).pack(anchor='w', pady=2)

        # Footer note
        fn_frame = tk.Frame(left, bg=THEME['bg'])
        fn_frame.pack(fill='x', pady=2)
        tk.Label(fn_frame, text='Footer note:', font=FONT_SM, bg=THEME['bg']).pack(side='left')
        self.footer_var = tk.StringVar(value=db.get_setting('quote_footer_note', 'VALID FOR ONLY 21 DAYS'))
        tk.Entry(fn_frame, textvariable=self.footer_var, font=FONT, width=26,
                 relief='solid', bd=1, bg=THEME['white']).pack(side='left', padx=4)

        # ── RIGHT: Quote Preview Table
        SectionTitle(right, '📋  Quote Preview').pack(fill='x', pady=(0, 4))

        cols = ('#', 'Description', 'Qty', 'Unit Price', 'Line Total', 'Action')
        self.tree = ttk.Treeview(right, columns=cols, show='headings', height=18)
        widths = [35, 260, 50, 110, 110, 60]
        for col, w in zip(cols, widths):
            self.tree.heading(col, text=col)
            self.tree.column(col, width=w, anchor='e' if col in ('Unit Price', 'Line Total') else 'w')
        self.tree.column('#', anchor='center')
        self.tree.column('Qty', anchor='center')
        self.tree.column('Action', anchor='center')

        style = ttk.Style()
        style.configure('Treeview', rowheight=22, font=FONT_SM)
        style.configure('Treeview.Heading', font=FONT_BOLD)

        vsb = ttk.Scrollbar(right, orient='vertical', command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side='left', fill='both', expand=True)
        vsb.pack(side='right', fill='y')
        self.tree.bind('<Delete>', lambda e: self._remove_item())
        self.tree.bind('<Button-3>', self._tree_right_click)

        # Totals panel
        totals_frame = tk.Frame(right, bg=THEME['bg'])
        totals_frame.pack(fill='x', pady=6)

        for label in ['Subtotal:', 'VAT 18%:', 'TOTAL:']:
            row = tk.Frame(totals_frame, bg=THEME['bg'])
            row.pack(anchor='e', pady=1)
            is_total = label == 'TOTAL:'
            tk.Label(row, text=label, font=FONT_BOLD if is_total else FONT,
                     bg=THEME['bg'], fg=THEME['accent'], width=12, anchor='e').pack(side='left')
            var = tk.StringVar(value='0')
            tk.Label(row, textvariable=var, font=('Helvetica', 12, 'bold') if is_total else FONT,
                     bg=THEME['bg'], fg=THEME['accent'] if is_total else THEME['text'],
                     width=16, anchor='e').pack(side='left')
            setattr(self, f'lbl_{"sub" if "Sub" in label else "vat" if "VAT" in label else "total"}', var)

        # Quote number display
        qn_frame = tk.Frame(right, bg=THEME['bg'])
        qn_frame.pack(anchor='e')
        tk.Label(qn_frame, text='Quote No:', font=FONT_SM, bg=THEME['bg']).pack(side='left')
        self.quote_no_var = tk.StringVar(value=db.get_setting('next_quote_number', '33717'))
        tk.Label(qn_frame, textvariable=self.quote_no_var, font=FONT_BOLD,
                 fg=THEME['accent'], bg=THEME['bg']).pack(side='left', padx=4)

    def _refresh_vehicles(self):
        conn = db.get_conn()
        vehicles = [r['name'] for r in conn.execute('SELECT name FROM vehicles WHERE active=1 ORDER BY name').fetchall()]
        pricelists = [r['name'] for r in conn.execute('SELECT name FROM pricelists WHERE active=1 ORDER BY name').fetchall()]
        conn.close()
        self.vehicle_cb['values'] = vehicles
        self.pricelist_cb['values'] = pricelists
        if pricelists:
            self.pricelist_cb.set(pricelists[0])

    def _on_vehicle_change(self, event=None):
        self.search_var.set('')
        self._on_search()

    def _on_search(self, *args):
        q = self.search_var.get().strip().lower()
        veh = self.vehicle_var.get()
        pl = self.pricelist_var.get()
        self.results_list.delete(0, 'end')
        if not q or len(q) < 2:
            return
        conn = db.get_conn()
        sql = '''SELECT p.name, p.price, p.vat_price FROM parts p
                 JOIN vehicles v ON p.vehicle_id = v.id
                 JOIN pricelists pl ON p.pricelist_id = pl.id
                 WHERE LOWER(p.name) LIKE ? AND p.active=1'''
        params = [f'%{q}%']
        if veh:
            sql += ' AND v.name=?'; params.append(veh)
        if pl:
            sql += ' AND pl.name=?'; params.append(pl)
        sql += ' ORDER BY p.name LIMIT 60'
        rows = conn.execute(sql, params).fetchall()
        conn.close()
        self._part_cache = {}
        for row in rows:
            display = f"{row['name']}  —  UGX {fmt_ugx(row['vat_price'] or row['price'])}"
            self.results_list.insert('end', display)
            self._part_cache[display] = {'name': row['name'], 'price': row['price'], 'vat_price': row['vat_price']}

    def _add_from_list(self, event=None):
        sel = self.results_list.curselection()
        if not sel:
            return
        display = self.results_list.get(sel[0])
        part = self._part_cache.get(display, {})
        custom = self.custom_price_var.get().strip()
        try:
            price = float(custom) if custom else float(part.get('vat_price') or part.get('price') or 0)
        except:
            price = 0
        try:
            qty = int(self.qty_var.get() or 1)
        except:
            qty = 1
        self._add_item(part.get('name', display.split('—')[0].strip()), qty, price)

    def _add_selected(self):
        self._add_from_list()

    def _add_custom_item(self):
        name = self.custom_name_var.get().strip()
        if not name:
            messagebox.showwarning('Missing', 'Enter a part name'); return
        try:
            price = float(self.custom_manual_price.get() or 0)
            qty = int(self.custom_manual_qty.get() or 1)
        except:
            messagebox.showerror('Error', 'Invalid price or quantity'); return
        self._add_item(name, qty, price)
        self.custom_name_var.set('')
        self.custom_manual_price.set('')

    def _add_item(self, name, qty, unit_price):
        line_total = qty * unit_price
        self.items.append({'description': name, 'qty': qty,
                           'unit_price': unit_price, 'line_total': line_total})
        self._refresh_tree()
        self._recalc()

    def _refresh_tree(self):
        self.tree.delete(*self.tree.get_children())
        for i, item in enumerate(self.items, 1):
            self.tree.insert('', 'end', iid=str(i-1),
                             values=(i, item['description'], item['qty'],
                                     fmt_ugx(item['unit_price']),
                                     fmt_ugx(item['line_total']), '✕ Remove'))
            self.tree.item(str(i-1), tags=('even' if i % 2 == 0 else 'odd',))
        self.tree.tag_configure('even', background=THEME['row_alt'])

    def _tree_right_click(self, event):
        iid = self.tree.identify_row(event.y)
        if iid:
            self.tree.selection_set(iid)
            menu = tk.Menu(self, tearoff=0)
            menu.add_command(label='✕ Remove Item', command=self._remove_item)
            menu.add_command(label='✏️ Edit Quantity', command=lambda: self._edit_qty(int(iid)))
            menu.post(event.x_root, event.y_root)

    def _remove_item(self):
        sel = self.tree.selection()
        if sel:
            idx = int(sel[0])
            self.items.pop(idx)
            self._refresh_tree()
            self._recalc()

    def _edit_qty(self, idx):
        new_qty = simpledialog.askinteger('Edit Qty', 'New quantity:', initialvalue=self.items[idx]['qty'])
        if new_qty and new_qty > 0:
            self.items[idx]['qty'] = new_qty
            self.items[idx]['line_total'] = new_qty * self.items[idx]['unit_price']
            self._refresh_tree()
            self._recalc()

    def _recalc(self):
        subtotal = sum(i['line_total'] for i in self.items)
        try:
            labour = float(self.labour_var.get() or 0)
        except:
            labour = 0
        subtotal += labour
        vat = subtotal * 0.18 if self.show_vat.get() else 0
        total = subtotal + vat
        self.lbl_sub.set(f"UGX {fmt_ugx(subtotal)}")
        self.lbl_vat.set(f"UGX {fmt_ugx(vat)}")
        self.lbl_total.set(f"UGX {fmt_ugx(total)}")

    def _get_quote_data(self):
        subtotal = sum(i['line_total'] for i in self.items)
        try:
            labour = float(self.labour_var.get() or 0)
        except:
            labour = 0
        subtotal += labour
        vat = subtotal * 0.18 if self.show_vat.get() else 0
        total = subtotal + vat
        return {
            'quote_number': self.quote_no_var.get(),
            'customer_name': self.f_customer.get(),
            'customer_id': self.f_cust_id.get(),
            'reg_no': self.f_reg.get(),
            'vehicle_make': self.vehicle_var.get(),
            'mileage': self.f_mileage.get(),
            'salesperson': self.f_salesperson.get(),
            'job_description': self.f_job.get(),
            'pricelist_name': self.pricelist_var.get(),
            'notes': self.f_notes.get(),
            'items': json.dumps(self.items),
            'labour': labour,
            'subtotal': subtotal,
            'vat_amount': vat,
            'total': total,
            'footer_note': self.footer_var.get(),
            'doc_type': 'QUOTATION',
            'created_at': datetime.now().strftime('%Y-%m-%d'),
        }

    def _save_quote(self):
        data = self._get_quote_data()
        if not data['customer_name']:
            messagebox.showwarning('Missing', 'Please enter customer name'); return
        conn = db.get_conn()
        try:
            if self.edit_data:
                conn.execute('''UPDATE quotes SET customer_name=?, customer_id=?, reg_no=?,
                    vehicle_make=?, mileage=?, salesperson=?, job_description=?, pricelist_name=?,
                    notes=?, items=?, subtotal=?, vat_amount=?, total=?, updated_at=CURRENT_TIMESTAMP
                    WHERE quote_number=?''',
                    (data['customer_name'], data['customer_id'], data['reg_no'],
                     data['vehicle_make'], data['mileage'], data['salesperson'],
                     data['job_description'], data['pricelist_name'], data['notes'],
                     data['items'], data['subtotal'], data['vat_amount'], data['total'],
                     data['quote_number']))
            else:
                qn = db.get_next_quote_number()
                self.quote_no_var.set(str(int(qn)+1))
                data['quote_number'] = qn
                conn.execute('''INSERT INTO quotes (quote_number, customer_name, customer_id, reg_no,
                    vehicle_make, mileage, salesperson, job_description, pricelist_name, notes,
                    items, subtotal, vat_amount, total) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
                    (data['quote_number'], data['customer_name'], data['customer_id'],
                     data['reg_no'], data['vehicle_make'], data['mileage'], data['salesperson'],
                     data['job_description'], data['pricelist_name'], data['notes'],
                     data['items'], data['subtotal'], data['vat_amount'], data['total']))
            conn.commit()
            messagebox.showinfo('Saved', f'Quote {data["quote_number"]} saved successfully!')
        except Exception as e:
            messagebox.showerror('Error', str(e))
        finally:
            conn.close()

    def _export_pdf(self):
        data = self._get_quote_data()
        settings = self._get_settings()
        import tempfile
        with tempfile.NamedTemporaryFile(suffix='.pdf', delete=False) as f:
            tmp = f.name
        try:
            path = build_quote_pdf(data, settings, tmp)
            saved = save_to_folder(path, data)
            os.startfile(saved) if os.name == 'nt' else os.system(f'xdg-open "{saved}"')
            messagebox.showinfo('PDF Exported', f'Saved to:\n{saved}')
        except Exception as e:
            messagebox.showerror('Error', str(e))

    def _export_excel(self):
        data = self._get_quote_data()
        settings = self._get_settings()
        import tempfile
        with tempfile.NamedTemporaryFile(suffix='.xlsx', delete=False) as f:
            tmp = f.name
        try:
            path = build_quote_excel(data, settings, tmp)
            saved = save_to_folder(path, data)
            os.startfile(saved) if os.name == 'nt' else os.system(f'xdg-open "{saved}"')
            messagebox.showinfo('Excel Exported', f'Saved to:\n{saved}')
        except Exception as e:
            messagebox.showerror('Error', str(e))

    def _to_invoice(self):
        data = self._get_quote_data()
        if not data['customer_name']:
            messagebox.showwarning('Missing', 'Please fill in customer name first'); return
        InvoiceDialog(self.app.root, data, self._get_settings())

    def _get_settings(self):
        conn = db.get_conn()
        rows = conn.execute('SELECT key, value FROM settings').fetchall()
        conn.close()
        return {r['key']: r['value'] for r in rows}

    def _clear(self):
        if messagebox.askyesno('Clear', 'Clear all items?'):
            self.items = []
            self._refresh_tree()
            self._recalc()

    def _load_edit(self, data):
        self.f_customer.set(data.get('customer_name', ''))
        self.f_cust_id.set(data.get('customer_id', ''))
        self.f_reg.set(data.get('reg_no', ''))
        self.f_mileage.set(data.get('mileage', ''))
        self.f_salesperson.set(data.get('salesperson', ''))
        self.f_job.set(data.get('job_description', ''))
        self.vehicle_var.set(data.get('vehicle_make', ''))
        self.pricelist_var.set(data.get('pricelist_name', ''))
        self.quote_no_var.set(data.get('quote_number', ''))
        self.items = json.loads(data.get('items', '[]'))
        self.labour_var.set(str(data.get('labour', 0)))
        self._refresh_tree()
        self._recalc()


# ─────────────────────────────────────────────
# INVOICE DIALOG
# ─────────────────────────────────────────────
class InvoiceDialog(tk.Toplevel):
    def __init__(self, parent, quote_data, settings):
        super().__init__(parent)
        self.title('Generate Invoice')
        self.configure(bg=THEME['bg'])
        self.geometry('520x540')
        self.quote_data = quote_data
        self.settings = settings
        self._build()

    def _build(self):
        tk.Label(self, text='Convert to Invoice', font=FONT_XL,
                 bg=THEME['accent'], fg='white').pack(fill='x', padx=0, pady=0, ipady=8)

        form = tk.Frame(self, bg=THEME['bg'], padx=20, pady=10)
        form.pack(fill='both', expand=True)

        inv_no = db.get_next_invoice_number()
        self.f_inv_no = LabelEntry(form, 'Invoice No:', default=inv_no, width=22); self.f_inv_no.pack(pady=3)
        self.f_payment_terms = LabelEntry(form, 'Payment Terms:', default=db.get_setting('default_payment_terms','Due upon receipt'), width=22); self.f_payment_terms.pack(pady=3)
        due = (datetime.now() + timedelta(days=30)).strftime('%Y-%m-%d')
        self.f_due = LabelEntry(form, 'Due Date:', default=due, width=22); self.f_due.pack(pady=3)
        self.f_paid = LabelEntry(form, 'Amount Paid (UGX):', default='0', width=22); self.f_paid.pack(pady=3)

        status_frame = tk.Frame(form, bg=THEME['bg'])
        status_frame.pack(fill='x', pady=3)
        tk.Label(status_frame, text='Payment Status:', font=FONT_SM, bg=THEME['bg'], width=18, anchor='w').pack(side='left')
        self.status_var = tk.StringVar(value='Unpaid')
        ttk.Combobox(status_frame, textvariable=self.status_var, values=['Unpaid', 'Partially Paid', 'Paid'], width=20, state='readonly').pack(side='left')

        self.f_notes = LabelEntry(form, 'Notes:', default=self.quote_data.get('notes',''), width=22); self.f_notes.pack(pady=3)
        self.f_footer = LabelEntry(form, 'Footer Note:', default=db.get_setting('invoice_footer_note','Thank you for your business!'), width=22); self.f_footer.pack(pady=3)

        btn_frame = tk.Frame(form, bg=THEME['bg'])
        btn_frame.pack(pady=10)
        ActionBtn(btn_frame, '📄 Export PDF', self._export_pdf).pack(side='left', padx=5)
        ActionBtn(btn_frame, '📊 Export Excel', self._export_excel, color='#217346').pack(side='left', padx=5)
        ActionBtn(btn_frame, '💾 Save Invoice', self._save_invoice, color=THEME['success']).pack(side='left', padx=5)
        ActionBtn(btn_frame, 'Close', self.destroy, color=THEME['danger']).pack(side='left', padx=5)

    def _get_inv_data(self):
        d = dict(self.quote_data)
        d.update({
            'invoice_number': self.f_inv_no.get(),
            'payment_terms': self.f_payment_terms.get(),
            'due_date': self.f_due.get(),
            'amount_paid': float(self.f_paid.get() or 0),
            'payment_status': self.status_var.get(),
            'notes': self.f_notes.get(),
            'footer_note': self.f_footer.get(),
            'doc_type': 'INVOICE',
        })
        return d

    def _save_invoice(self):
        d = self._get_inv_data()
        conn = db.get_conn()
        try:
            conn.execute('''INSERT INTO invoices (invoice_number, customer_name, customer_id,
                reg_no, vehicle_make, salesperson, job_description, items, subtotal, vat_amount,
                total, amount_paid, payment_status, payment_terms, due_date, notes)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
                (d['invoice_number'], d['customer_name'], d['customer_id'], d['reg_no'],
                 d['vehicle_make'], d['salesperson'], d['job_description'], d['items'],
                 d['subtotal'], d['vat_amount'], d['total'], d['amount_paid'],
                 d['payment_status'], d['payment_terms'], d['due_date'], d['notes']))
            conn.commit()
            messagebox.showinfo('Saved', f'Invoice {d["invoice_number"]} saved!')
        except Exception as e:
            messagebox.showerror('Error', str(e))
        finally:
            conn.close()

    def _export_pdf(self):
        d = self._get_inv_data()
        import tempfile
        with tempfile.NamedTemporaryFile(suffix='.pdf', delete=False) as f:
            tmp = f.name
        path = build_quote_pdf(d, self.settings, tmp)
        saved = save_to_folder(path, d)
        os.startfile(saved) if os.name == 'nt' else os.system(f'xdg-open "{saved}"')
        messagebox.showinfo('Done', f'Invoice PDF saved:\n{saved}')

    def _export_excel(self):
        d = self._get_inv_data()
        import tempfile
        with tempfile.NamedTemporaryFile(suffix='.xlsx', delete=False) as f:
            tmp = f.name
        path = build_quote_excel(d, self.settings, tmp)
        saved = save_to_folder(path, d)
        os.startfile(saved) if os.name == 'nt' else os.system(f'xdg-open "{saved}"')
        messagebox.showinfo('Done', f'Invoice Excel saved:\n{saved}')


# ─────────────────────────────────────────────
# QUOTE HISTORY
# ─────────────────────────────────────────────
class QuoteHistory(tk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent, bg=THEME['bg'])
        self.app = app
        self._build()
        self._load()

    def _build(self):
        topbar = tk.Frame(self, bg=THEME['accent'], pady=6)
        topbar.pack(fill='x')
        tk.Label(topbar, text='📂  Quote History', font=FONT_XL, bg=THEME['accent'], fg='white').pack(side='left', padx=15)
        ActionBtn(topbar, '🔄 Refresh', self._load).pack(side='right', padx=10)

        # Search bar
        sf = tk.Frame(self, bg=THEME['bg'], padx=10, pady=6)
        sf.pack(fill='x')
        tk.Label(sf, text='Search:', font=FONT_SM, bg=THEME['bg']).pack(side='left')
        self.search_var = tk.StringVar()
        self.search_var.trace('w', self._filter)
        tk.Entry(sf, textvariable=self.search_var, font=FONT, width=30, relief='solid', bd=1).pack(side='left', padx=4)

        # Treeview
        cols = ('Quote No', 'Customer', 'Vehicle', 'Reg No', 'Total', 'Status', 'Date')
        self.tree = ttk.Treeview(self, columns=cols, show='headings', height=22)
        widths = [80, 180, 150, 100, 120, 80, 110]
        for col, w in zip(cols, widths):
            self.tree.heading(col, text=col)
            self.tree.column(col, width=w)

        vsb = ttk.Scrollbar(self, orient='vertical', command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side='left', fill='both', expand=True, padx=(10, 0), pady=5)
        vsb.pack(side='right', fill='y', pady=5)

        self.tree.bind('<Double-Button-1>', self._open_quote)
        self.tree.bind('<Button-3>', self._right_click)

    def _load(self):
        self.tree.delete(*self.tree.get_children())
        conn = db.get_conn()
        rows = conn.execute('SELECT * FROM quotes ORDER BY created_at DESC').fetchall()
        conn.close()
        self._all_rows = rows
        for row in rows:
            self.tree.insert('', 'end', iid=str(row['id']),
                             values=(row['quote_number'], row['customer_name'],
                                     row['vehicle_make'], row['reg_no'],
                                     f"UGX {fmt_ugx(row['total'])}",
                                     row['status'], row['created_at'][:10]))

    def _filter(self, *args):
        q = self.search_var.get().lower()
        self.tree.delete(*self.tree.get_children())
        for row in self._all_rows:
            if q in str(row['customer_name']).lower() or q in str(row['reg_no']).lower() \
               or q in str(row['quote_number']).lower() or q in str(row['vehicle_make']).lower():
                self.tree.insert('', 'end', iid=str(row['id']),
                                 values=(row['quote_number'], row['customer_name'],
                                         row['vehicle_make'], row['reg_no'],
                                         f"UGX {fmt_ugx(row['total'])}",
                                         row['status'], row['created_at'][:10]))

    def _get_selected_row(self):
        sel = self.tree.selection()
        if not sel: return None
        conn = db.get_conn()
        row = conn.execute('SELECT * FROM quotes WHERE id=?', (int(sel[0]),)).fetchone()
        conn.close()
        return dict(row) if row else None

    def _open_quote(self, event=None):
        row = self._get_selected_row()
        if row:
            self.app.open_quote_edit(row)

    def _right_click(self, event):
        iid = self.tree.identify_row(event.y)
        if iid:
            self.tree.selection_set(iid)
            menu = tk.Menu(self, tearoff=0)
            menu.add_command(label='✏️ Edit', command=self._open_quote)
            menu.add_command(label='📄 Export PDF', command=self._export_pdf)
            menu.add_command(label='📊 Export Excel', command=self._export_excel)
            menu.add_command(label='🧾 → Invoice', command=self._to_invoice)
            menu.add_separator()
            menu.add_command(label='🗑 Delete', command=self._delete)
            menu.post(event.x_root, event.y_root)

    def _export_pdf(self):
        row = self._get_selected_row()
        if not row: return
        settings = {r[0]: r[1] for r in db.get_conn().execute('SELECT key,value FROM settings').fetchall()}
        row['doc_type'] = 'QUOTATION'
        import tempfile
        with tempfile.NamedTemporaryFile(suffix='.pdf', delete=False) as f:
            tmp = f.name
        path = build_quote_pdf(row, settings, tmp)
        saved = save_to_folder(path, row)
        os.startfile(saved) if os.name == 'nt' else os.system(f'xdg-open "{saved}"')

    def _export_excel(self):
        row = self._get_selected_row()
        if not row: return
        settings = {r[0]: r[1] for r in db.get_conn().execute('SELECT key,value FROM settings').fetchall()}
        row['doc_type'] = 'QUOTATION'
        import tempfile
        with tempfile.NamedTemporaryFile(suffix='.xlsx', delete=False) as f:
            tmp = f.name
        path = build_quote_excel(row, settings, tmp)
        saved = save_to_folder(path, row)
        os.startfile(saved) if os.name == 'nt' else os.system(f'xdg-open "{saved}"')

    def _to_invoice(self):
        row = self._get_selected_row()
        if not row: return
        settings = {r[0]: r[1] for r in db.get_conn().execute('SELECT key,value FROM settings').fetchall()}
        row['doc_type'] = 'QUOTATION'
        InvoiceDialog(self.app.root, row, settings)

    def _delete(self):
        row = self._get_selected_row()
        if row and messagebox.askyesno('Delete', f"Delete quote {row['quote_number']}?"):
            conn = db.get_conn()
            conn.execute('DELETE FROM quotes WHERE id=?', (row['id'],))
            conn.commit()
            conn.close()
            self._load()


# ─────────────────────────────────────────────
# ADMIN PANEL
# ─────────────────────────────────────────────
class AdminPanel(tk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent, bg=THEME['bg'])
        self.app = app
        self._authenticated = False
        self._build()

    def _build(self):
        topbar = tk.Frame(self, bg=THEME['accent'], pady=6)
        topbar.pack(fill='x')
        tk.Label(topbar, text='⚙️  Admin Panel', font=FONT_XL, bg=THEME['accent'], fg='white').pack(side='left', padx=15)

        # Auth gate
        self.auth_frame = tk.Frame(self, bg=THEME['bg'])
        self.auth_frame.pack(fill='both', expand=True)
        tk.Label(self.auth_frame, text='🔒 Enter Admin Password', font=FONT_LG, bg=THEME['bg']).pack(pady=30)
        pw_frame = tk.Frame(self.auth_frame, bg=THEME['bg'])
        pw_frame.pack()
        self.pw_var = tk.StringVar()
        tk.Entry(pw_frame, textvariable=self.pw_var, show='*', font=FONT, width=20, relief='solid', bd=1).pack(side='left', padx=4)
        ActionBtn(pw_frame, 'Login', self._auth).pack(side='left')

        self.main_frame = tk.Frame(self, bg=THEME['bg'])

    def _auth(self):
        pw = self.pw_var.get()
        if pw == db.get_setting('admin_password', 'admin123'):
            self.auth_frame.pack_forget()
            self._build_admin()
            self.main_frame.pack(fill='both', expand=True)
        else:
            messagebox.showerror('Wrong Password', 'Incorrect password')

    def _build_admin(self):
        nb = ttk.Notebook(self.main_frame)
        nb.pack(fill='both', expand=True, padx=10, pady=8)

        # Tabs
        self._tab_company(nb)
        self._tab_vehicles(nb)
        self._tab_pricelists(nb)
        self._tab_parts(nb)
        self._tab_import(nb)
        self._tab_password(nb)

    def _tab_company(self, nb):
        tab = tk.Frame(nb, bg=THEME['bg'])
        nb.add(tab, text='🏢 Company Settings')
        tk.Label(tab, text='Company & Quote Settings', font=FONT_LG, bg=THEME['bg']).pack(pady=8)

        fields = [
            ('company_name', 'Company Name:'),
            ('company_address', 'Address:'),
            ('company_po_box', 'PO Box:'),
            ('company_phone', 'Phone:'),
            ('company_email', 'Email:'),
            ('company_tagline', 'Tagline:'),
            ('managing_director', 'Managing Director:'),
            ('vat_rate', 'VAT Rate (%):'),
            ('quote_valid_days', 'Quote Valid (days):'),
            ('next_quote_number', 'Next Quote Number:'),
            ('next_invoice_number', 'Next Invoice Number:'),
            ('output_folder', 'Output Folder:'),
            ('quote_footer_note', 'Quote Footer Note:'),
            ('invoice_footer_note', 'Invoice Footer Note:'),
            ('default_payment_terms', 'Default Payment Terms:'),
        ]
        self._company_vars = {}
        scroll = ScrollFrame(tab, bg=THEME['bg'])
        for key, label in fields:
            row = tk.Frame(scroll, bg=THEME['bg'])
            row.pack(fill='x', padx=20, pady=2)
            tk.Label(row, text=label, font=FONT_SM, bg=THEME['bg'], width=24, anchor='w').pack(side='left')
            var = tk.StringVar(value=db.get_setting(key, ''))
            tk.Entry(row, textvariable=var, font=FONT, width=40, relief='solid', bd=1,
                     bg=THEME['white']).pack(side='left', padx=4)
            self._company_vars[key] = var
            if key == 'output_folder':
                ActionBtn(row, '📁 Browse', lambda k=key: self._browse_folder(k), color='#555').pack(side='left', padx=2)

        ActionBtn(scroll, '💾 Save Settings', self._save_company, color=THEME['success']).pack(pady=10)

    def _browse_folder(self, key):
        folder = filedialog.askdirectory()
        if folder:
            self._company_vars[key].set(folder)

    def _save_company(self):
        for key, var in self._company_vars.items():
            db.set_setting(key, var.get())
        messagebox.showinfo('Saved', 'Company settings saved!')

    def _tab_vehicles(self, nb):
        tab = tk.Frame(nb, bg=THEME['bg'])
        nb.add(tab, text='🚗 Vehicles')

        top = tk.Frame(tab, bg=THEME['bg'], padx=10, pady=6)
        top.pack(fill='x')
        tk.Label(top, text='Vehicle Name:', font=FONT_SM, bg=THEME['bg']).pack(side='left')
        self.new_veh_var = tk.StringVar()
        tk.Entry(top, textvariable=self.new_veh_var, font=FONT, width=30, relief='solid', bd=1,
                 bg=THEME['white']).pack(side='left', padx=4)
        ActionBtn(top, '+ Add Vehicle', self._add_vehicle, color=THEME['success']).pack(side='left', padx=4)

        cols = ('ID', 'Vehicle Name', 'Parts Count', 'Active')
        self.veh_tree = ttk.Treeview(tab, columns=cols, show='headings', height=18)
        for col in cols:
            self.veh_tree.heading(col, text=col)
            self.veh_tree.column(col, width=150)
        self.veh_tree.pack(fill='both', expand=True, padx=10, pady=5)
        self.veh_tree.bind('<Button-3>', self._veh_right_click)
        self._load_vehicles()

    def _add_vehicle(self):
        name = self.new_veh_var.get().strip()
        if not name: return
        conn = db.get_conn()
        try:
            conn.execute('INSERT INTO vehicles (name) VALUES (?)', (name,))
            conn.commit()
            self.new_veh_var.set('')
            self._load_vehicles()
        except:
            messagebox.showerror('Error', 'Vehicle already exists')
        finally:
            conn.close()

    def _load_vehicles(self):
        self.veh_tree.delete(*self.veh_tree.get_children())
        conn = db.get_conn()
        rows = conn.execute('''SELECT v.id, v.name, COUNT(p.id) as cnt, v.active
                               FROM vehicles v LEFT JOIN parts p ON p.vehicle_id=v.id
                               GROUP BY v.id ORDER BY v.name''').fetchall()
        conn.close()
        for row in rows:
            self.veh_tree.insert('', 'end', values=(row['id'], row['name'], row['cnt'],
                                                     '✅' if row['active'] else '❌'))

    def _veh_right_click(self, event):
        iid = self.veh_tree.identify_row(event.y)
        if iid:
            self.veh_tree.selection_set(iid)
            menu = tk.Menu(self, tearoff=0)
            menu.add_command(label='Toggle Active/Inactive', command=self._toggle_vehicle)
            menu.add_command(label='Rename', command=self._rename_vehicle)
            menu.post(event.x_root, event.y_root)

    def _toggle_vehicle(self):
        sel = self.veh_tree.selection()
        if sel:
            vid = self.veh_tree.item(sel[0])['values'][0]
            conn = db.get_conn()
            conn.execute('UPDATE vehicles SET active = 1 - active WHERE id=?', (vid,))
            conn.commit(); conn.close()
            self._load_vehicles()

    def _rename_vehicle(self):
        sel = self.veh_tree.selection()
        if sel:
            old = self.veh_tree.item(sel[0])['values'][1]
            new = simpledialog.askstring('Rename', 'New name:', initialvalue=old)
            if new:
                vid = self.veh_tree.item(sel[0])['values'][0]
                conn = db.get_conn()
                conn.execute('UPDATE vehicles SET name=? WHERE id=?', (new, vid))
                conn.commit(); conn.close()
                self._load_vehicles()

    def _tab_pricelists(self, nb):
        tab = tk.Frame(nb, bg=THEME['bg'])
        nb.add(tab, text='💰 Price Lists')

        top = tk.Frame(tab, bg=THEME['bg'], padx=10, pady=6)
        top.pack(fill='x')
        tk.Label(top, text='Name:', font=FONT_SM, bg=THEME['bg']).pack(side='left')
        self.new_pl_name = tk.StringVar()
        tk.Entry(top, textvariable=self.new_pl_name, font=FONT, width=20, relief='solid', bd=1, bg=THEME['white']).pack(side='left', padx=4)
        tk.Label(top, text='Description:', font=FONT_SM, bg=THEME['bg']).pack(side='left')
        self.new_pl_desc = tk.StringVar()
        tk.Entry(top, textvariable=self.new_pl_desc, font=FONT, width=30, relief='solid', bd=1, bg=THEME['white']).pack(side='left', padx=4)
        ActionBtn(top, '+ Add', self._add_pricelist, color=THEME['success']).pack(side='left', padx=4)

        cols = ('ID', 'Name', 'Description', 'Active')
        self.pl_tree = ttk.Treeview(tab, columns=cols, show='headings', height=18)
        for col in cols:
            self.pl_tree.heading(col, text=col)
            self.pl_tree.column(col, width=180)
        self.pl_tree.pack(fill='both', expand=True, padx=10, pady=5)
        self.pl_tree.bind('<Button-3>', self._pl_right_click)
        self._load_pricelists()

    def _add_pricelist(self):
        name = self.new_pl_name.get().strip()
        if not name: return
        conn = db.get_conn()
        try:
            conn.execute('INSERT INTO pricelists (name, description) VALUES (?,?)',
                         (name, self.new_pl_desc.get()))
            conn.commit()
            self._load_pricelists()
        except Exception as e:
            messagebox.showerror('Error', str(e))
        finally:
            conn.close()

    def _load_pricelists(self):
        self.pl_tree.delete(*self.pl_tree.get_children())
        conn = db.get_conn()
        rows = conn.execute('SELECT * FROM pricelists ORDER BY name').fetchall()
        conn.close()
        for r in rows:
            self.pl_tree.insert('', 'end', values=(r['id'], r['name'], r['description'] or '', '✅' if r['active'] else '❌'))

    def _pl_right_click(self, event):
        iid = self.pl_tree.identify_row(event.y)
        if iid:
            self.pl_tree.selection_set(iid)
            menu = tk.Menu(self, tearoff=0)
            menu.add_command(label='Toggle Active', command=self._toggle_pl)
            menu.post(event.x_root, event.y_root)

    def _toggle_pl(self):
        sel = self.pl_tree.selection()
        if sel:
            pid = self.pl_tree.item(sel[0])['values'][0]
            conn = db.get_conn()
            conn.execute('UPDATE pricelists SET active = 1 - active WHERE id=?', (pid,))
            conn.commit(); conn.close()
            self._load_pricelists()

    def _tab_parts(self, nb):
        tab = tk.Frame(nb, bg=THEME['bg'])
        nb.add(tab, text='🔧 Parts')

        top = tk.Frame(tab, bg=THEME['bg'], padx=10, pady=6)
        top.pack(fill='x')

        # Add part form
        tk.Label(top, text='Part Name:', font=FONT_SM, bg=THEME['bg']).pack(side='left')
        self.new_part_name = tk.StringVar()
        tk.Entry(top, textvariable=self.new_part_name, font=FONT, width=20, relief='solid', bd=1, bg=THEME['white']).pack(side='left', padx=2)
        tk.Label(top, text='Vehicle:', font=FONT_SM, bg=THEME['bg']).pack(side='left')
        self.new_part_veh = tk.StringVar()
        conn = db.get_conn()
        vehs = [r['name'] for r in conn.execute('SELECT name FROM vehicles WHERE active=1 ORDER BY name').fetchall()]
        pls = [r['name'] for r in conn.execute('SELECT name FROM pricelists WHERE active=1').fetchall()]
        conn.close()
        ttk.Combobox(top, textvariable=self.new_part_veh, values=vehs, width=18, state='readonly').pack(side='left', padx=2)
        tk.Label(top, text='List:', font=FONT_SM, bg=THEME['bg']).pack(side='left')
        self.new_part_pl = tk.StringVar()
        ttk.Combobox(top, textvariable=self.new_part_pl, values=pls, width=10, state='readonly').pack(side='left', padx=2)
        tk.Label(top, text='Price:', font=FONT_SM, bg=THEME['bg']).pack(side='left')
        self.new_part_price = tk.StringVar()
        tk.Entry(top, textvariable=self.new_part_price, font=FONT, width=10, relief='solid', bd=1, bg=THEME['white']).pack(side='left', padx=2)
        tk.Label(top, text='VAT Price:', font=FONT_SM, bg=THEME['bg']).pack(side='left')
        self.new_part_vat = tk.StringVar()
        tk.Entry(top, textvariable=self.new_part_vat, font=FONT, width=10, relief='solid', bd=1, bg=THEME['white']).pack(side='left', padx=2)
        ActionBtn(top, '+ Add', self._add_part, color=THEME['success']).pack(side='left', padx=4)

        # Filter row
        filter_row = tk.Frame(tab, bg=THEME['bg'], padx=10)
        filter_row.pack(fill='x', pady=2)
        tk.Label(filter_row, text='Filter:', font=FONT_SM, bg=THEME['bg']).pack(side='left')
        self.part_filter = tk.StringVar()
        self.part_filter.trace('w', lambda *a: self._load_parts())
        tk.Entry(filter_row, textvariable=self.part_filter, font=FONT, width=25, relief='solid', bd=1, bg=THEME['white']).pack(side='left', padx=4)

        cols = ('ID', 'Part Name', 'Vehicle', 'Price List', 'Price', 'VAT Price', 'Active')
        self.part_tree = ttk.Treeview(tab, columns=cols, show='headings', height=18)
        widths = [50, 200, 150, 100, 100, 100, 60]
        for col, w in zip(cols, widths):
            self.part_tree.heading(col, text=col)
            self.part_tree.column(col, width=w)
        vsb = ttk.Scrollbar(tab, orient='vertical', command=self.part_tree.yview)
        self.part_tree.configure(yscrollcommand=vsb.set)
        self.part_tree.pack(side='left', fill='both', expand=True, padx=(10, 0), pady=5)
        vsb.pack(side='right', fill='y', pady=5, padx=(0,10))
        self.part_tree.bind('<Button-3>', self._part_right_click)
        self._load_parts()

    def _add_part(self):
        name = self.new_part_name.get().strip()
        veh = self.new_part_veh.get()
        pl = self.new_part_pl.get()
        if not name or not veh or not pl:
            messagebox.showwarning('Missing', 'Fill in name, vehicle and price list'); return
        try:
            price = float(self.new_part_price.get() or 0)
            vat_price = float(self.new_part_vat.get() or price * 1.18)
        except:
            messagebox.showerror('Error', 'Invalid price'); return
        conn = db.get_conn()
        veh_id = conn.execute('SELECT id FROM vehicles WHERE name=?', (veh,)).fetchone()['id']
        pl_id = conn.execute('SELECT id FROM pricelists WHERE name=?', (pl,)).fetchone()['id']
        conn.execute('INSERT INTO parts (name, vehicle_id, pricelist_id, price, vat_price) VALUES (?,?,?,?,?)',
                     (name, veh_id, pl_id, price, vat_price))
        conn.commit(); conn.close()
        self._load_parts()
        self.new_part_name.set('')

    def _load_parts(self):
        self.part_tree.delete(*self.part_tree.get_children())
        q = self.part_filter.get().lower() if hasattr(self, 'part_filter') else ''
        conn = db.get_conn()
        rows = conn.execute('''SELECT p.id, p.name, v.name as veh, pl.name as plist,
                               p.price, p.vat_price, p.active
                               FROM parts p JOIN vehicles v ON p.vehicle_id=v.id
                               JOIN pricelists pl ON p.pricelist_id=pl.id
                               WHERE LOWER(p.name) LIKE ? ORDER BY p.name LIMIT 500''',
                            (f'%{q}%',)).fetchall()
        conn.close()
        for r in rows:
            self.part_tree.insert('', 'end', values=(r['id'], r['name'], r['veh'], r['plist'],
                                                      fmt_ugx(r['price']), fmt_ugx(r['vat_price']),
                                                      '✅' if r['active'] else '❌'))

    def _part_right_click(self, event):
        iid = self.part_tree.identify_row(event.y)
        if iid:
            self.part_tree.selection_set(iid)
            menu = tk.Menu(self, tearoff=0)
            menu.add_command(label='Edit Price', command=self._edit_part_price)
            menu.add_command(label='Toggle Active', command=self._toggle_part)
            menu.add_command(label='Delete', command=self._delete_part)
            menu.post(event.x_root, event.y_root)

    def _edit_part_price(self):
        sel = self.part_tree.selection()
        if sel:
            pid = self.part_tree.item(sel[0])['values'][0]
            new_price = simpledialog.askfloat('Edit Price', 'New price (excl VAT):')
            if new_price is not None:
                conn = db.get_conn()
                conn.execute('UPDATE parts SET price=?, vat_price=? WHERE id=?',
                             (new_price, new_price * 1.18, pid))
                conn.commit(); conn.close()
                self._load_parts()

    def _toggle_part(self):
        sel = self.part_tree.selection()
        if sel:
            pid = self.part_tree.item(sel[0])['values'][0]
            conn = db.get_conn()
            conn.execute('UPDATE parts SET active = 1 - active WHERE id=?', (pid,))
            conn.commit(); conn.close()
            self._load_parts()

    def _delete_part(self):
        sel = self.part_tree.selection()
        if sel and messagebox.askyesno('Delete', 'Delete this part?'):
            pid = self.part_tree.item(sel[0])['values'][0]
            conn = db.get_conn()
            conn.execute('DELETE FROM parts WHERE id=?', (pid,))
            conn.commit(); conn.close()
            self._load_parts()

    def _tab_import(self, nb):
        tab = tk.Frame(nb, bg=THEME['bg'])
        nb.add(tab, text='📥 Import Price List')

        tk.Label(tab, text='Import New Price List from Excel', font=FONT_LG, bg=THEME['bg']).pack(pady=15)
        tk.Label(tab, text='Select an Excel file with the same format as MOWE price lists.',
                 font=FONT_SM, bg=THEME['bg'], fg=THEME['text_light']).pack()

        info = tk.Label(tab,
            text='Expected format:\n'
                 '• Sheet name = Vehicle name\n'
                 '• Row with S/N, Part name, Price columns\n'
                 '• This will add/update parts for the selected vehicle and price list',
            font=FONT_SM, bg=THEME['light'], justify='left', padx=15, pady=10)
        info.pack(padx=20, pady=10, fill='x')

        pl_row = tk.Frame(tab, bg=THEME['bg'])
        pl_row.pack(pady=5)
        tk.Label(pl_row, text='Price List Name:', font=FONT_SM, bg=THEME['bg']).pack(side='left')
        self.import_pl_var = tk.StringVar()
        conn = db.get_conn()
        pls = [r['name'] for r in conn.execute('SELECT name FROM pricelists ORDER BY name').fetchall()]
        conn.close()
        ttk.Combobox(pl_row, textvariable=self.import_pl_var, values=pls, width=25).pack(side='left', padx=8)

        ActionBtn(tab, '📁 Select Excel File & Import', self._import_excel, color=THEME['accent']).pack(pady=10)

        self.import_log = tk.Text(tab, height=12, font=FONT_SM, bg='#f8f8f8', relief='solid', bd=1)
        self.import_log.pack(fill='both', expand=True, padx=20, pady=5)

    def _import_excel(self):
        pl_name = self.import_pl_var.get().strip()
        if not pl_name:
            messagebox.showwarning('Missing', 'Enter a price list name'); return
        path = filedialog.askopenfilename(filetypes=[('Excel files', '*.xlsx *.xls')])
        if not path: return

        self.import_log.delete('1.0', 'end')
        self.import_log.insert('end', f'Importing from: {path}\n')

        try:
            import pandas as pd
            xl = pd.read_excel(path, sheet_name=None)
            conn = db.get_conn()
            conn.execute('INSERT OR IGNORE INTO pricelists (name) VALUES (?)', (pl_name,))
            pl_id = conn.execute('SELECT id FROM pricelists WHERE name=?', (pl_name,)).fetchone()['id']

            total_added = 0
            for sheet_name, df in xl.items():
                if sheet_name in ('Technical specifications',): continue
                # Try to add vehicle
                conn.execute('INSERT OR IGNORE INTO vehicles (name) VALUES (?)', (sheet_name,))
                veh_id = conn.execute('SELECT id FROM vehicles WHERE name=?', (sheet_name,)).fetchone()['id']
                added = 0
                for i, row in df.iterrows():
                    vals = list(row.values)
                    try:
                        num = vals[0]
                        name = str(vals[1]).strip() if len(vals) > 1 else ''
                        price = float(str(vals[2]).strip()) if len(vals) > 2 and str(vals[2]) not in ['nan','None',''] else 0
                        vat_p = float(str(vals[3]).strip()) if len(vals) > 3 and str(vals[3]) not in ['nan','None',''] else price * 1.18
                        float(str(num).strip())
                        if name and price > 0:
                            conn.execute('''INSERT INTO parts (name, vehicle_id, pricelist_id, price, vat_price)
                                           VALUES (?,?,?,?,?)''', (name, veh_id, pl_id, price, vat_p))
                            added += 1
                    except:
                        pass
                total_added += added
                self.import_log.insert('end', f'  Sheet "{sheet_name}": {added} parts imported\n')

            conn.commit()
            conn.close()
            self.import_log.insert('end', f'\n✅ Done! Total: {total_added} parts imported.\n')
        except Exception as e:
            self.import_log.insert('end', f'\n❌ Error: {e}\n')

    def _tab_password(self, nb):
        tab = tk.Frame(nb, bg=THEME['bg'])
        nb.add(tab, text='🔑 Change Password')
        tk.Label(tab, text='Change Admin Password', font=FONT_LG, bg=THEME['bg']).pack(pady=20)
        self.pw_old = LabelEntry(tab, 'Current Password:'); self.pw_old.entry.config(show='*'); self.pw_old.pack(pady=4)
        self.pw_new1 = LabelEntry(tab, 'New Password:'); self.pw_new1.entry.config(show='*'); self.pw_new1.pack(pady=4)
        self.pw_new2 = LabelEntry(tab, 'Confirm New:'); self.pw_new2.entry.config(show='*'); self.pw_new2.pack(pady=4)
        ActionBtn(tab, '🔑 Change Password', self._change_pw, color=THEME['success']).pack(pady=10)

    def _change_pw(self):
        old = self.pw_old.get()
        if old != db.get_setting('admin_password', 'admin123'):
            messagebox.showerror('Error', 'Current password is wrong'); return
        n1, n2 = self.pw_new1.get(), self.pw_new2.get()
        if n1 != n2:
            messagebox.showerror('Error', "New passwords don't match"); return
        if len(n1) < 4:
            messagebox.showerror('Error', 'Password too short (min 4 chars)'); return
        db.set_setting('admin_password', n1)
        messagebox.showinfo('Done', 'Password changed successfully!')


# ─────────────────────────────────────────────
# INVOICE HISTORY
# ─────────────────────────────────────────────
class InvoiceHistory(tk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent, bg=THEME['bg'])
        self.app = app
        self._build()
        self._load()

    def _build(self):
        topbar = tk.Frame(self, bg=THEME['accent'], pady=6)
        topbar.pack(fill='x')
        tk.Label(topbar, text='🧾  Invoice History', font=FONT_XL, bg=THEME['accent'], fg='white').pack(side='left', padx=15)
        ActionBtn(topbar, '🔄 Refresh', self._load).pack(side='right', padx=10)

        cols = ('Invoice No', 'Customer', 'Vehicle', 'Total', 'Paid', 'Status', 'Due Date', 'Date')
        self.tree = ttk.Treeview(self, columns=cols, show='headings', height=24)
        widths = [90, 160, 130, 120, 100, 90, 100, 100]
        for col, w in zip(cols, widths):
            self.tree.heading(col, text=col)
            self.tree.column(col, width=w)
        vsb = ttk.Scrollbar(self, orient='vertical', command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side='left', fill='both', expand=True, padx=(10, 0), pady=5)
        vsb.pack(side='right', fill='y', pady=5)
        self.tree.bind('<Button-3>', self._right_click)

    def _load(self):
        self.tree.delete(*self.tree.get_children())
        conn = db.get_conn()
        rows = conn.execute('SELECT * FROM invoices ORDER BY created_at DESC').fetchall()
        conn.close()
        for row in rows:
            self.tree.insert('', 'end', iid=str(row['id']),
                             values=(row['invoice_number'], row['customer_name'],
                                     row['vehicle_make'], f"UGX {fmt_ugx(row['total'])}",
                                     f"UGX {fmt_ugx(row['amount_paid'])}",
                                     row['payment_status'], row['due_date'] or '', row['created_at'][:10]))
            if row['payment_status'] == 'Paid':
                self.tree.item(str(row['id']), tags=('paid',))
            elif row['payment_status'] == 'Unpaid':
                self.tree.item(str(row['id']), tags=('unpaid',))
        self.tree.tag_configure('paid', background='#d4f7d4')
        self.tree.tag_configure('unpaid', background='#fde8e8')

    def _right_click(self, event):
        iid = self.tree.identify_row(event.y)
        if iid:
            self.tree.selection_set(iid)
            menu = tk.Menu(self, tearoff=0)
            menu.add_command(label='📄 Export PDF', command=self._export_pdf)
            menu.add_command(label='📊 Export Excel', command=self._export_excel)
            menu.add_command(label='Mark as Paid', command=lambda: self._set_status('Paid'))
            menu.add_command(label='Mark as Unpaid', command=lambda: self._set_status('Unpaid'))
            menu.add_separator()
            menu.add_command(label='🗑 Delete', command=self._delete)
            menu.post(event.x_root, event.y_root)

    def _get_row(self):
        sel = self.tree.selection()
        if not sel: return None
        conn = db.get_conn()
        row = conn.execute('SELECT * FROM invoices WHERE id=?', (int(sel[0]),)).fetchone()
        conn.close()
        return dict(row) if row else None

    def _export_pdf(self):
        row = self._get_row()
        if not row: return
        settings = {r[0]: r[1] for r in db.get_conn().execute('SELECT key,value FROM settings').fetchall()}
        row['doc_type'] = 'INVOICE'
        import tempfile
        with tempfile.NamedTemporaryFile(suffix='.pdf', delete=False) as f:
            tmp = f.name
        path = build_quote_pdf(row, settings, tmp)
        saved = save_to_folder(path, row)
        os.startfile(saved) if os.name == 'nt' else os.system(f'xdg-open "{saved}"')

    def _export_excel(self):
        row = self._get_row()
        if not row: return
        settings = {r[0]: r[1] for r in db.get_conn().execute('SELECT key,value FROM settings').fetchall()}
        row['doc_type'] = 'INVOICE'
        import tempfile
        with tempfile.NamedTemporaryFile(suffix='.xlsx', delete=False) as f:
            tmp = f.name
        path = build_quote_excel(row, settings, tmp)
        saved = save_to_folder(path, row)
        os.startfile(saved) if os.name == 'nt' else os.system(f'xdg-open "{saved}"')

    def _set_status(self, status):
        row = self._get_row()
        if row:
            conn = db.get_conn()
            conn.execute('UPDATE invoices SET payment_status=? WHERE id=?', (status, row['id']))
            conn.commit(); conn.close()
            self._load()

    def _delete(self):
        row = self._get_row()
        if row and messagebox.askyesno('Delete', f"Delete invoice {row['invoice_number']}?"):
            conn = db.get_conn()
            conn.execute('DELETE FROM invoices WHERE id=?', (row['id'],))
            conn.commit(); conn.close()
            self._load()


# ─────────────────────────────────────────────
# COMING SOON PLACEHOLDER (SOCKETS)
# ─────────────────────────────────────────────
class ComingSoon(tk.Frame):
    def __init__(self, parent, title, description, icon='🔌'):
        super().__init__(parent, bg=THEME['bg'])
        topbar = tk.Frame(self, bg=THEME['accent'], pady=6)
        topbar.pack(fill='x')
        tk.Label(topbar, text=f'{icon}  {title}', font=FONT_XL, bg=THEME['accent'], fg='white').pack(side='left', padx=15)

        center = tk.Frame(self, bg=THEME['bg'])
        center.place(relx=0.5, rely=0.5, anchor='center')
        tk.Label(center, text=icon, font=('Helvetica', 64), bg=THEME['bg']).pack()
        tk.Label(center, text=title, font=('Helvetica', 20, 'bold'), bg=THEME['bg'], fg=THEME['accent']).pack(pady=5)
        tk.Label(center, text='Coming in the Next Update', font=FONT_LG, bg=THEME['bg'], fg=THEME['accent2']).pack()
        tk.Label(center, text=description, font=FONT, bg=THEME['bg'], fg=THEME['text_light'],
                 wraplength=400, justify='center').pack(pady=10)
        tk.Label(center, text='🔌 Socket ready — plug-in update will connect here',
                 font=FONT_SM, bg=THEME['light'], fg=THEME['text_light'], padx=12, pady=6).pack(pady=5)


# ─────────────────────────────────────────────
# DASHBOARD
# ─────────────────────────────────────────────
class Dashboard(tk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent, bg=THEME['bg'])
        self.app = app
        self._build()

    def _build(self):
        topbar = tk.Frame(self, bg=THEME['accent'], pady=8)
        topbar.pack(fill='x')
        tk.Label(topbar, text='🏠  Dashboard', font=FONT_XL, bg=THEME['accent'], fg='white').pack(side='left', padx=15)
        tk.Label(topbar, text=datetime.now().strftime('%A, %d %B %Y'),
                 font=FONT, bg=THEME['accent'], fg='#aaccee').pack(side='right', padx=15)

        # Stats row
        stats_frame = tk.Frame(self, bg=THEME['bg'])
        stats_frame.pack(fill='x', padx=15, pady=12)

        stats = self._get_stats()
        cards = [
            ('📋 Total Quotes', str(stats['total_quotes']), THEME['accent']),
            ('🧾 Total Invoices', str(stats['total_invoices']), '#7b4fc8'),
            ('💰 Unpaid Invoices', str(stats['unpaid']), THEME['danger']),
            ('✅ Paid Invoices', str(stats['paid']), THEME['success']),
        ]
        for title, value, color in cards:
            card = tk.Frame(stats_frame, bg=color, padx=20, pady=12, relief='flat')
            card.pack(side='left', padx=8, fill='y')
            tk.Label(card, text=value, font=('Helvetica', 28, 'bold'), bg=color, fg='white').pack()
            tk.Label(card, text=title, font=FONT_SM, bg=color, fg='#ddddff').pack()

        # Recent quotes
        recent_frame = tk.Frame(self, bg=THEME['bg'], padx=15)
        recent_frame.pack(fill='both', expand=True)
        tk.Label(recent_frame, text='Recent Quotes', font=FONT_LG, bg=THEME['bg'], anchor='w').pack(fill='x', pady=(0, 4))

        cols = ('Quote No', 'Customer', 'Vehicle', 'Total', 'Date')
        tree = ttk.Treeview(recent_frame, columns=cols, show='headings', height=12)
        for col in cols:
            tree.heading(col, text=col)
            tree.column(col, width=150)
        tree.pack(fill='both', expand=True)

        conn = db.get_conn()
        for row in conn.execute('SELECT * FROM quotes ORDER BY created_at DESC LIMIT 20').fetchall():
            tree.insert('', 'end', values=(row['quote_number'], row['customer_name'],
                                           row['vehicle_make'], f"UGX {fmt_ugx(row['total'])}",
                                           row['created_at'][:10]))
        conn.close()

        # Quick new quote button
        ActionBtn(self, '  ➕  New Quotation  ', self.app.show_new_quote,
                  color=THEME['accent2']).pack(pady=8)

    def _get_stats(self):
        conn = db.get_conn()
        total_quotes = conn.execute('SELECT COUNT(*) FROM quotes').fetchone()[0]
        total_invoices = conn.execute('SELECT COUNT(*) FROM invoices').fetchone()[0]
        unpaid = conn.execute("SELECT COUNT(*) FROM invoices WHERE payment_status='Unpaid'").fetchone()[0]
        paid = conn.execute("SELECT COUNT(*) FROM invoices WHERE payment_status='Paid'").fetchone()[0]
        conn.close()
        return {'total_quotes': total_quotes, 'total_invoices': total_invoices, 'unpaid': unpaid, 'paid': paid}


# ─────────────────────────────────────────────
# MAIN APP
# ─────────────────────────────────────────────
class CapitalAutotuneApp:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title('Capital Autotune — Workshop Management System')
        self.root.geometry('1280x800')
        self.root.configure(bg=THEME['bg'])
        self.root.minsize(1000, 650)

        try:
            self.root.iconbitmap(default='')
        except:
            pass

        self._build_layout()
        self._show_page('dashboard')

    def _build_layout(self):
        # Sidebar
        self.sidebar = tk.Frame(self.root, bg=THEME['sidebar'], width=200)
        self.sidebar.pack(side='left', fill='y')
        self.sidebar.pack_propagate(False)

        # Logo area
        logo_frame = tk.Frame(self.sidebar, bg=THEME['sidebar'], pady=15)
        logo_frame.pack(fill='x')
        tk.Label(logo_frame, text='🔧', font=('Helvetica', 28), bg=THEME['sidebar'], fg=THEME['accent2']).pack()
        tk.Label(logo_frame, text='Capital', font=('Helvetica', 13, 'bold'), bg=THEME['sidebar'], fg='white').pack()
        tk.Label(logo_frame, text='Autotune', font=('Helvetica', 11), bg=THEME['sidebar'], fg='#aaccee').pack()
        ttk.Separator(self.sidebar).pack(fill='x', padx=10, pady=5)

        # Nav items
        self.nav_buttons = {}
        nav_items = [
            ('dashboard', '🏠', 'Dashboard'),
            ('new_quote', '📋', 'New Quote'),
            ('quote_history', '📂', 'Quote History'),
            ('invoices', '🧾', 'Invoices'),
            ('job_cards', '🔩', 'Job Cards'),
            ('inventory', '📦', 'Inventory'),
            ('customers', '👥', 'Customers'),
            ('reports', '📊', 'Reports'),
            ('admin', '⚙️', 'Admin'),
        ]
        for page, icon, label in nav_items:
            btn = tk.Button(self.sidebar, text=f'  {icon}  {label}',
                            font=FONT, bg=THEME['sidebar'], fg='#ccddee',
                            anchor='w', relief='flat', padx=12, pady=8,
                            cursor='hand2', activebackground=THEME['sidebar_hover'],
                            activeforeground='white',
                            command=lambda p=page: self._show_page(p))
            btn.pack(fill='x')
            self.nav_buttons[page] = btn

        # Version
        tk.Label(self.sidebar, text='v1.0 — Phase 1', font=('Helvetica', 8),
                 bg=THEME['sidebar'], fg='#667788').pack(side='bottom', pady=5)
        tk.Label(self.sidebar, text='"Where safety & comfort is"', font=('Helvetica', 7, 'italic'),
                 bg=THEME['sidebar'], fg='#556677', wraplength=180).pack(side='bottom')

        # Content area
        self.content = tk.Frame(self.root, bg=THEME['bg'])
        self.content.pack(side='left', fill='both', expand=True)

        # Pages dict
        self.pages = {}

    def _show_page(self, page):
        # Update nav highlight
        for p, btn in self.nav_buttons.items():
            btn.configure(bg=THEME['sidebar'] if p != page else THEME['sidebar_hover'],
                          fg='white' if p == page else '#ccddee',
                          font=FONT_BOLD if p == page else FONT)

        # Destroy current
        for w in self.content.winfo_children():
            w.pack_forget()

        # Build if needed (lazy loading for performance)
        if page == 'dashboard':
            frame = Dashboard(self.content, self)
        elif page == 'new_quote':
            frame = QuoteBuilder(self.content, self)
        elif page == 'quote_history':
            frame = QuoteHistory(self.content, self)
        elif page == 'invoices':
            frame = InvoiceHistory(self.content, self)
        elif page == 'admin':
            frame = AdminPanel(self.content, self)
        elif page == 'job_cards':
            frame = ComingSoon(self.content, 'Job Cards', 'Convert quotes to job cards, assign mechanics, track job status from Pending → In Progress → Completed.', '🔩')
        elif page == 'inventory':
            frame = ComingSoon(self.content, 'Inventory & Stock', 'Track parts stock levels, get low-stock alerts, auto-deduct parts used per job, manage suppliers and reorders.', '📦')
        elif page == 'customers':
            frame = ComingSoon(self.content, 'Customer Database', 'Full customer profiles with vehicle history, all past quotes and invoices per customer, loyalty tracking.', '👥')
        elif page == 'reports':
            frame = ComingSoon(self.content, 'Reports & Analytics', 'Revenue by month, most quoted parts, busiest vehicles, salesperson performance, profit margins.', '📊')
        else:
            frame = tk.Frame(self.content, bg=THEME['bg'])

        frame.pack(fill='both', expand=True)
        self.current_page = frame

    def show_new_quote(self):
        self._show_page('new_quote')

    def open_quote_edit(self, data):
        for w in self.content.winfo_children():
            w.pack_forget()
        frame = QuoteBuilder(self.content, self, edit_data=data)
        frame.pack(fill='both', expand=True)
        for p, btn in self.nav_buttons.items():
            btn.configure(bg=THEME['sidebar'] if p != 'new_quote' else THEME['sidebar_hover'])
        self.current_page = frame

    def run(self):
        self.root.mainloop()


# ─────────────────────────────────────────────
# ENTRY POINT
# ─────────────────────────────────────────────
def main():
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    data_dir = os.path.join(base_dir, 'data')
    os.makedirs(data_dir, exist_ok=True)

    db.init_db()

    # Load price data if not already loaded
    conn = db.get_conn()
    count = conn.execute('SELECT COUNT(*) FROM parts').fetchone()[0]
    conn.close()

    if count == 0:
        json_path = os.path.join(data_dir, 'pricelists.json')
        if os.path.exists(json_path):
            db.load_pricelists_from_json(json_path)

    app = CapitalAutotuneApp()
    app.run()

if __name__ == '__main__':
    main()
PYEOF
echo "app.py done"