from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, HRFlowable
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_RIGHT, TA_LEFT
from reportlab.pdfgen import canvas
from reportlab.platypus import BaseDocTemplate, PageTemplate, Frame
import os, json
from datetime import datetime

def format_ugx(amount):
    try:
        return f"UGX {float(amount):,.0f}"
    except:
        return str(amount)

def build_quote_pdf(quote_data, settings, output_path):
    """Generate professional quote PDF"""
    doc = SimpleDocTemplate(output_path, pagesize=A4,
                            topMargin=15*mm, bottomMargin=15*mm,
                            leftMargin=15*mm, rightMargin=15*mm)

    theme = colors.HexColor(settings.get('theme_color', '#1a3a5c'))
    styles = getSampleStyleSheet()

    def style(name, **kwargs):
        s = ParagraphStyle(name, parent=styles['Normal'], **kwargs)
        return s

    story = []

    # === HEADER ===
    company_name = settings.get('company_name', 'CAPITAL AUTOTUNE LIMITED')
    tagline = settings.get('company_tagline', '')
    phone = settings.get('company_phone', '')
    email = settings.get('company_email', '')
    address = settings.get('company_address', '')
    po_box = settings.get('company_po_box', '')

    header_data = [
        [Paragraph(f'<font size="16"><b>{company_name}</b></font>', style('ch', textColor=theme, alignment=TA_CENTER)),
         Paragraph('<b>ORIGINAL</b>', style('orig', textColor=colors.red, alignment=TA_RIGHT))],
        [Paragraph(f'<font size="9">{tagline}</font>', style('ct', alignment=TA_CENTER, textColor=colors.grey)), ''],
        [Paragraph(f'<font size="8">Tel: {phone} | Email: {email}</font>', style('ci', alignment=TA_CENTER)), ''],
        [Paragraph(f'<font size="8">{address} | {po_box}</font>', style('ca', alignment=TA_CENTER)), ''],
    ]
    header_table = Table(header_data, colWidths=[155*mm, 25*mm])
    header_table.setStyle(TableStyle([
        ('SPAN', (0, 0), (0, 3)),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 1),
    ]))
    story.append(header_table)
    story.append(HRFlowable(width='100%', thickness=2, color=theme))
    story.append(Spacer(1, 4*mm))

    # === QUOTATION TITLE ===
    doc_type = quote_data.get('doc_type', 'QUOTATION')
    story.append(Paragraph(f'<b>{doc_type}</b>', style('title', fontSize=13, textColor=theme, alignment=TA_CENTER)))
    story.append(Spacer(1, 3*mm))

    # === META INFO (two columns) ===
    created = quote_data.get('created_at', datetime.now().strftime('%Y-%m-%d'))[:10]
    doc_no = quote_data.get('quote_number', quote_data.get('invoice_number', ''))
    meta = [
        [Paragraph('<b>ISSUED BY:</b>', style('ml')), '', Paragraph('<b>Date:</b>', style('ml')), Paragraph(created, style('ml'))],
        [Paragraph(company_name, style('ml')), '', Paragraph(f'<b>{doc_type} NO:</b>', style('ml')), Paragraph(f'<b>{doc_no}</b>', style('ml', textColor=theme))],
        [Paragraph('<b>ISSUED TO:</b>', style('ml')), '', Paragraph('<b>Customer ID:</b>', style('ml')), Paragraph(quote_data.get('customer_id', ''), style('ml'))],
        [Paragraph(quote_data.get('customer_name', ''), style('ml', fontName='Helvetica-Bold')), '',
         Paragraph('<b>Reg No:</b>', style('ml')), Paragraph(quote_data.get('reg_no', ''), style('ml', fontName='Helvetica-Bold'))],
        [Paragraph('', style('ml')), '', Paragraph('<b>Mileage:</b>', style('ml')), Paragraph(quote_data.get('mileage', ''), style('ml'))],
        [Paragraph(f'<b>Vehicle:</b> {quote_data.get("vehicle_make", "")}', style('ml')), '',
         Paragraph('<b>Salesperson:</b>', style('ml')), Paragraph(quote_data.get('salesperson', ''), style('ml'))],
        [Paragraph(f'<b>Job:</b> {quote_data.get("job_description", "")}', style('ml')), '', '', ''],
    ]
    if quote_data.get('doc_type') == 'INVOICE':
        meta.append([Paragraph(f'<b>Payment Terms:</b> {quote_data.get("payment_terms", "")}', style('ml')), '',
                     Paragraph('<b>Due Date:</b>', style('ml')), Paragraph(quote_data.get('due_date', ''), style('ml'))])

    meta_table = Table(meta, colWidths=[80*mm, 5*mm, 45*mm, 50*mm])
    meta_table.setStyle(TableStyle([
        ('FONTSIZE', (0, 0), (-1, -1), 8),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 2),
        ('TOPPADDING', (0, 0), (-1, -1), 2),
    ]))
    story.append(meta_table)
    story.append(Spacer(1, 4*mm))

    # === ITEMS TABLE ===
    items = json.loads(quote_data.get('items', '[]'))
    table_data = [['#', 'Description', 'Qty', 'Unit Price (UGX)', 'Line Total (UGX)']]

    for i, item in enumerate(items, 1):
        table_data.append([
            str(i),
            item.get('description', ''),
            str(item.get('qty', 1)),
            f"{float(item.get('unit_price', 0)):,.0f}",
            f"{float(item.get('line_total', 0)):,.0f}",
        ])

    # Labour row if present
    if quote_data.get('labour') and float(quote_data.get('labour', 0)) > 0:
        table_data.append(['', 'LABOUR', '', '', f"{float(quote_data.get('labour', 0)):,.0f}"])

    items_table = Table(table_data, colWidths=[10*mm, 80*mm, 15*mm, 40*mm, 40*mm])
    items_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), theme),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 9),
        ('ALIGN', (2, 0), (-1, -1), 'RIGHT'),
        ('ALIGN', (0, 0), (0, -1), 'CENTER'),
        ('FONTSIZE', (0, 1), (-1, -1), 8),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f0f4f8')]),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#cccccc')),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 3),
        ('TOPPADDING', (0, 0), (-1, -1), 3),
    ]))
    story.append(items_table)
    story.append(Spacer(1, 3*mm))

    # === TOTALS ===
    subtotal = float(quote_data.get('subtotal', 0))
    vat = float(quote_data.get('vat_amount', 0))
    total = float(quote_data.get('total', 0))

    totals_data = [
        ['', 'Subtotal:', f"{subtotal:,.0f}"],
        ['', 'VAT 18%:', f"{vat:,.0f}"],
        ['', 'TOTAL:', f"{total:,.0f}"],
    ]
    if quote_data.get('doc_type') == 'INVOICE':
        paid = float(quote_data.get('amount_paid', 0))
        balance = total - paid
        totals_data.append(['', 'Amount Paid:', f"{paid:,.0f}"])
        totals_data.append(['', 'Balance Due:', f"{balance:,.0f}"])

    totals_table = Table(totals_data, colWidths=[105*mm, 45*mm, 30*mm])
    totals_table.setStyle(TableStyle([
        ('ALIGN', (1, 0), (-1, -1), 'RIGHT'),
        ('FONTSIZE', (0, 0), (-1, -1), 9),
        ('FONTNAME', (1, 2), (-1, 2), 'Helvetica-Bold'),
        ('TEXTCOLOR', (1, 2), (-1, 2), theme),
        ('FONTSIZE', (1, 2), (-1, 2), 11),
        ('LINEABOVE', (1, 2), (-1, 2), 1, theme),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 3),
    ]))
    story.append(totals_table)
    story.append(Spacer(1, 6*mm))

    # === NOTES ===
    notes = quote_data.get('notes', '')
    if notes:
        story.append(Paragraph(f'<b>Notes:</b> {notes}', style('notes', fontSize=8)))
        story.append(Spacer(1, 3*mm))

    # === SIGNATURE ===
    sig_data = [
        ['Signed:', '……………………………………………………………………………'],
        [settings.get('managing_director', ''), ''],
        ['MANAGING DIRECTOR', ''],
    ]
    sig_table = Table(sig_data, colWidths=[40*mm, 100*mm])
    sig_table.setStyle(TableStyle([
        ('FONTSIZE', (0, 0), (-1, -1), 8),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 2),
    ]))
    story.append(sig_table)
    story.append(Spacer(1, 5*mm))

    # === FOOTER ===
    footer_note = quote_data.get('footer_note', settings.get('quote_footer_note', 'VALID FOR ONLY 21 DAYS'))
    story.append(HRFlowable(width='100%', thickness=1, color=theme))
    story.append(Paragraph(footer_note, style('footer', fontSize=8, alignment=TA_CENTER, textColor=theme)))

    doc.build(story)
    return output_path

def build_quote_excel(quote_data, settings, output_path):
    """Generate quote in Excel format matching original style"""
    import openpyxl
    from openpyxl.styles import Font, Alignment, PatternFill, Border, Side, numbers
    from openpyxl.utils import get_column_letter

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = 'Quotation'

    theme_hex = settings.get('theme_color', '#1a3a5c').replace('#', '')
    thin = Side(style='thin', color='999999')
    border = Border(left=thin, right=thin, top=thin, bottom=thin)

    def cell(row, col, value='', bold=False, size=10, color=None, bg=None,
             align='left', wrap=False, number_fmt=None):
        c = ws.cell(row=row, column=col, value=value)
        c.font = Font(bold=bold, size=size, color=color or '000000')
        c.alignment = Alignment(horizontal=align, vertical='center', wrap_text=wrap)
        if bg:
            c.fill = PatternFill('solid', fgColor=bg)
        if number_fmt:
            c.number_format = number_fmt
        return c

    # Column widths
    ws.column_dimensions['A'].width = 6
    ws.column_dimensions['B'].width = 40
    ws.column_dimensions['C'].width = 8
    ws.column_dimensions['D'].width = 18
    ws.column_dimensions['E'].width = 18

    # Header
    ws.merge_cells('A1:E1')
    cell(1, 1, settings.get('company_name', 'CAPITAL AUTOTUNE LIMITED'), bold=True, size=14, align='center', color=theme_hex)
    ws.merge_cells('A2:E2')
    cell(2, 1, settings.get('company_tagline', ''), size=9, align='center', color='888888')
    ws.merge_cells('A3:E3')
    cell(3, 1, f"Tel: {settings.get('company_phone','')} | {settings.get('company_email','')}", size=8, align='center')
    ws.row_dimensions[1].height = 22
    ws.row_dimensions[2].height = 14
    ws.row_dimensions[3].height = 13

    # Quotation title
    ws.merge_cells('A4:D4')
    doc_type = quote_data.get('doc_type', 'QUOTATION')
    cell(4, 1, doc_type, bold=True, size=12, align='center', color=theme_hex)
    cell(4, 5, 'ORIGINAL', bold=True, color='CC0000', align='right')
    ws.row_dimensions[4].height = 18

    # Meta
    r = 6
    cell(r, 1, 'ISSUED BY:', bold=True, size=8)
    cell(r, 4, 'Date:', bold=True, size=8)
    cell(r, 5, quote_data.get('created_at', '')[:10], size=8)
    r += 1
    ws.merge_cells(f'A{r}:C{r}')
    cell(r, 1, settings.get('company_name', ''), size=8)
    cell(r, 4, f'{doc_type} NO:', bold=True, size=8)
    cell(r, 5, quote_data.get('quote_number', quote_data.get('invoice_number', '')), bold=True, size=8, color=theme_hex)
    r += 1
    cell(r, 1, 'ISSUED TO:', bold=True, size=8)
    cell(r, 4, 'Customer ID:', bold=True, size=8)
    cell(r, 5, quote_data.get('customer_id', ''), size=8)
    r += 1
    ws.merge_cells(f'A{r}:C{r}')
    cell(r, 1, quote_data.get('customer_name', ''), bold=True, size=9)
    cell(r, 4, 'Reg No:', bold=True, size=8)
    cell(r, 5, quote_data.get('reg_no', ''), bold=True, size=8)
    r += 1
    ws.merge_cells(f'A{r}:C{r}')
    cell(r, 1, f"Vehicle: {quote_data.get('vehicle_make', '')}", size=8)
    cell(r, 4, 'Mileage:', bold=True, size=8)
    cell(r, 5, quote_data.get('mileage', ''), size=8)
    r += 1
    cell(r, 1, 'Salesperson:', bold=True, size=8)
    cell(r, 2, quote_data.get('salesperson', ''), size=8)
    cell(r, 4, 'Job:', bold=True, size=8)
    cell(r, 5, quote_data.get('job_description', ''), size=8)
    r += 2

    # Items header
    for col, (label, align) in enumerate([('Qty', 'center'), ('Description', 'left'),
                                           ('Unit Price', 'right'), ('Line Total', 'right')], 1):
        c = ws.cell(row=r, column=col + 0 if col > 1 else col)

    headers = [('#', 'A'), ('Description', 'B'), ('Qty', 'C'), ('Unit Price (UGX)', 'D'), ('Line Total (UGX)', 'E')]
    for label, col_letter in headers:
        c = ws[f'{col_letter}{r}']
        c.value = label
        c.font = Font(bold=True, color='FFFFFF', size=9)
        c.fill = PatternFill('solid', fgColor=theme_hex)
        c.alignment = Alignment(horizontal='center' if col_letter in ['A','C'] else 'right' if col_letter in ['D','E'] else 'left', vertical='center')
        c.border = border
    ws.row_dimensions[r].height = 15
    r += 1

    items = json.loads(quote_data.get('items', '[]'))
    for i, item in enumerate(items, 1):
        bg = 'F0F4F8' if i % 2 == 0 else 'FFFFFF'
        cell(r, 1, i, align='center', bg=bg, size=8)
        cell(r, 2, item.get('description', ''), bg=bg, size=8)
        cell(r, 3, item.get('qty', 1), align='center', bg=bg, size=8)
        cell(r, 4, float(item.get('unit_price', 0)), align='right', bg=bg, size=8, number_fmt='#,##0')
        cell(r, 5, float(item.get('line_total', 0)), align='right', bg=bg, size=8, number_fmt='#,##0')
        for col in range(1, 6):
            ws.cell(r, col).border = border
        ws.row_dimensions[r].height = 14
        r += 1

    if quote_data.get('labour') and float(quote_data.get('labour', 0)) > 0:
        cell(r, 2, 'LABOUR', bold=True, size=8)
        cell(r, 5, float(quote_data.get('labour', 0)), align='right', size=8, number_fmt='#,##0')
        r += 1

    r += 1
    # Totals
    for label, val in [('Subtotal', quote_data.get('subtotal', 0)),
                        ('VAT 18%', quote_data.get('vat_amount', 0)),
                        ('TOTAL', quote_data.get('total', 0))]:
        is_total = label == 'TOTAL'
        cell(r, 4, label + ':', bold=is_total, align='right', size=9 if is_total else 8,
             color=theme_hex if is_total else '000000')
        cell(r, 5, float(val), bold=is_total, align='right', size=9 if is_total else 8,
             color=theme_hex if is_total else '000000', number_fmt='#,##0')
        r += 1

    r += 2
    # Signature
    cell(r, 1, 'Signed:', bold=True, size=8)
    ws.merge_cells(f'B{r}:E{r}')
    cell(r, 2, '…………………………………………………………………………………………', size=9)
    r += 1
    cell(r, 1, settings.get('managing_director', ''), size=8)
    r += 1
    cell(r, 1, 'MANAGING DIRECTOR', bold=True, size=8)
    r += 2
    ws.merge_cells(f'A{r}:E{r}')
    footer = quote_data.get('footer_note', settings.get('quote_footer_note', 'VALID FOR ONLY 21 DAYS'))
    cell(r, 1, footer, align='center', color=theme_hex, bold=True, size=9)

    # Address footer
    r += 1
    ws.merge_cells(f'A{r}:E{r}')
    cell(r, 1, f"{settings.get('company_address','')} | {settings.get('company_po_box','')}",
         align='center', size=7, color='888888')

    wb.save(output_path)
    return output_path

