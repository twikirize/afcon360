import sqlite3
import json
import os
from datetime import datetime

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data', 'capital_autotune.db')

def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = get_conn()
    c = conn.cursor()

    c.executescript('''
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT
        );

        CREATE TABLE IF NOT EXISTS vehicles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            active INTEGER DEFAULT 1
        );

        CREATE TABLE IF NOT EXISTS pricelists (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            description TEXT,
            active INTEGER DEFAULT 1,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS parts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            vehicle_id INTEGER,
            pricelist_id INTEGER,
            price REAL DEFAULT 0,
            vat_price REAL DEFAULT 0,
            category TEXT DEFAULT 'General',
            active INTEGER DEFAULT 1,
            FOREIGN KEY(vehicle_id) REFERENCES vehicles(id),
            FOREIGN KEY(pricelist_id) REFERENCES pricelists(id)
        );

        CREATE TABLE IF NOT EXISTS customers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            customer_id TEXT,
            address TEXT,
            phone TEXT,
            email TEXT,
            active INTEGER DEFAULT 1,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS quotes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            quote_number TEXT UNIQUE NOT NULL,
            customer_name TEXT,
            customer_id TEXT,
            reg_no TEXT,
            vehicle_make TEXT,
            mileage TEXT,
            salesperson TEXT,
            job_description TEXT,
            pricelist_name TEXT,
            status TEXT DEFAULT 'Draft',
            items TEXT,
            subtotal REAL DEFAULT 0,
            vat_amount REAL DEFAULT 0,
            total REAL DEFAULT 0,
            notes TEXT,
            valid_days INTEGER DEFAULT 21,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS invoices (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            invoice_number TEXT UNIQUE NOT NULL,
            quote_id INTEGER,
            customer_name TEXT,
            customer_id TEXT,
            reg_no TEXT,
            vehicle_make TEXT,
            salesperson TEXT,
            job_description TEXT,
            items TEXT,
            subtotal REAL DEFAULT 0,
            vat_amount REAL DEFAULT 0,
            total REAL DEFAULT 0,
            amount_paid REAL DEFAULT 0,
            payment_status TEXT DEFAULT 'Unpaid',
            payment_terms TEXT DEFAULT 'Due upon receipt',
            due_date TEXT,
            notes TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(quote_id) REFERENCES quotes(id)
        );

        -- SOCKET: job_cards table ready for Phase 3
        CREATE TABLE IF NOT EXISTS job_cards (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            job_number TEXT UNIQUE NOT NULL,
            quote_id INTEGER,
            invoice_id INTEGER,
            mechanic_name TEXT,
            status TEXT DEFAULT 'Pending',
            notes TEXT,
            started_at TEXT,
            completed_at TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(quote_id) REFERENCES quotes(id),
            FOREIGN KEY(invoice_id) REFERENCES invoices(id)
        );

        -- SOCKET: inventory table ready for Phase 4
        CREATE TABLE IF NOT EXISTS inventory (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            part_name TEXT NOT NULL,
            part_number TEXT,
            quantity INTEGER DEFAULT 0,
            reorder_level INTEGER DEFAULT 5,
            unit_cost REAL DEFAULT 0,
            supplier TEXT,
            location TEXT,
            active INTEGER DEFAULT 1,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        );

        -- SOCKET: suppliers table ready for Phase 6
        CREATE TABLE IF NOT EXISTS suppliers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            contact_person TEXT,
            phone TEXT,
            email TEXT,
            address TEXT,
            active INTEGER DEFAULT 1,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );

        -- SOCKET: users table ready for Phase 8
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            full_name TEXT,
            role TEXT DEFAULT 'staff',
            active INTEGER DEFAULT 1,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
    ''')

    # Default settings
    defaults = {
        'company_name': 'CAPITAL AUTOTUNE LIMITED',
        'company_address': 'Plot 440, Mawanda Road Kampala',
        'company_po_box': 'P.O. Box 22157 Kampala, Uganda',
        'company_phone': '+256 0392912017 / +256 774510799',
        'company_email': 'capital.autotune@gmail.com',
        'company_tagline': '"Where your safety & comfort is"',
        'managing_director': 'NUWAGABA DIXON',
        'vat_rate': '18',
        'quote_valid_days': '21',
        'next_quote_number': '33717',
        'next_invoice_number': '1001',
        'output_folder': os.path.expanduser('~/Desktop/CapitalAutotune_Quotes'),
        'admin_password': 'admin123',
        'theme_color': '#1a3a5c',
        'quote_footer_note': 'VALID FOR ONLY 21 DAYS',
        'invoice_footer_note': 'Thank you for your business!',
        'show_vat_on_quote': '1',
        'default_payment_terms': 'Due upon receipt',
    }
    for k, v in defaults.items():
        c.execute('INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)', (k, v))

    conn.commit()
    conn.close()

def get_setting(key, default=''):
    conn = get_conn()
    row = conn.execute('SELECT value FROM settings WHERE key=?', (key,)).fetchone()
    conn.close()
    return row['value'] if row else default

def set_setting(key, value):
    conn = get_conn()
    conn.execute('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)', (key, str(value)))
    conn.commit()
    conn.close()

def get_next_quote_number():
    n = int(get_setting('next_quote_number', '33717'))
    set_setting('next_quote_number', n + 1)
    return str(n)

def get_next_invoice_number():
    n = int(get_setting('next_invoice_number', '1001'))
    set_setting('next_invoice_number', n + 1)
    return f'INV-{n}'

def load_pricelists_from_json(json_path):
    """Import price data from JSON into DB"""
    with open(json_path) as f:
        data = json.load(f)

    conn = get_conn()
    c = conn.cursor()

    # Get or create MOWE pricelist
    c.execute('INSERT OR IGNORE INTO pricelists (name, description) VALUES (?, ?)',
              ('MOWE', 'Ministry of Water & Environment Framework Contract'))
    c.execute('SELECT id FROM pricelists WHERE name=?', ('MOWE',))
    pl_id = c.fetchone()[0]

    for veh_name, veh_data in data.items():
        # Add vehicle
        c.execute('INSERT OR IGNORE INTO vehicles (name) VALUES (?)', (veh_name,))
        c.execute('SELECT id FROM vehicles WHERE name=?', (veh_name,))
        veh_id = c.fetchone()[0]

        # Add parts
        for part_name, prices in veh_data['parts'].items():
            c.execute('''INSERT INTO parts (name, vehicle_id, pricelist_id, price, vat_price)
                         VALUES (?, ?, ?, ?, ?)
                         ON CONFLICT DO NOTHING''',
                      (part_name, veh_id, pl_id, prices['price'], prices['vat_price']))

    conn.commit()
    conn.close()

